/**
 * 请在白鹭引擎的Main.ts中调用 platform.login() 方法调用至此处。
 */
//屏幕宽高
var screenWidth;
var screenHeight;

class WxgamePlatform {

    name = 'wxgame'

    login() {
        return new Promise((resolve, reject) => {
          //登录
            wx.login({
                success: (res) => {
                    console.log('登录接口调用成功');
                    //得到用户授权信息
                    wx.getSetting({
                      success:(res_2)=>{
                        var authSetting = res_2.authSetting
                        //判断用户是否已经授权
                        if (authSetting['scope.userInfo']) {
                          //已经授权
                          console.log(`用户已经授权,返回用户信息`);
                          //返回登录凭证
                          resolve({res:res,type:'code'});
                        }
                        else {
                          //未有授权
                          console.log(`用户暂未授权，创建授权按钮`)
                          //创建授权按钮
                          this.createUserInfoButton().then((res)=>{
                            //判断是否成功授权
                            resolve(res);
                          });
                        }
                      }
                    })
                    
                }
            })
        })
    }

    getUserInfo() {
        return new Promise((resolve, reject) => {
            wx.getUserInfo({
                withCredentials: true,
                success: function (res) {
                    var userInfo = res.userInfo
                    var nickName = userInfo.nickName
                    var avatarUrl = userInfo.avatarUrl
                    var gender = userInfo.gender //性别 0：未知、1：男、2：女
                    var province = userInfo.province
                    var city = userInfo.city
                    var country = userInfo.country
                    resolve(userInfo);
                }
            })
        })
    }

    //得到机器信息(可补充)
    getSystemInfoSync() {
      const res = wx.getSystemInfoSync();
      screenHeight = res.screenHeight;
      screenWidth = res.screenWidth;
      console.log(`手机屏幕宽高${screenHeight}/${screenWidth}`); 
      //返回值回Egret
      return res;
    }


    //创建全屏授权按钮,只有在真机上才可看到
    //style在文档中有很多是必填的，但其实不需要
    //在此方法中创建两个按钮，用于模拟开始游戏及排行榜等，在点击相应位置的按钮          时，授权后同时进入相应的界面
    createUserInfoButton() {
      return new Promise((resolve,reject)=>{
        //开始按钮
        let button = wx.createUserInfoButton({
          type: 'text',
          text: '模拟此按钮为开始位置上的授权按钮',
          style: {
            left: 0,
            top: 0,
            backgroundColor:`#000000`,
            width: screenWidth / 2,
            height: screenHeight / 2,
            color: '#ffffff',
            fontSize: 16,
          }
        })
        //排行榜按钮
        let buttonRank = wx.createUserInfoButton({
          type:'text',
          text:'模拟此按钮为排行榜位置上的授权按钮',
          style: {
            left: screenWidth / 2,
            top: screenHeight / 2,
            backgroundColor: `#00ff00`,
            width: screenWidth / 2,
            height: screenHeight / 2,
            color: '#ffffff',
            fontSize: 16,
          }
        })
        //显示
        button.show();
        buttonRank.show();
        //添加监听
        button.onTap((res) => {
          //得到用户信息
          let userInfo = res.userInfo;
          //如果用户信息为空，则弹窗强制用户授权
          if (!userInfo) {
            wx.showModal({
              title: '提示',
              content: '为了获取更好的游戏体验，请先授权获取用户头像和昵称',
              showCancel: false,
            })
          }
          else {
            //返回
            resolve({res:res,type:'start'});
            //隐藏
            button.hide();
            buttonRank.hide();
            //销毁
            button.destroy();
            buttonRank.destroy();
          }
        })
        buttonRank.onTap((res)=>{
          //得到用户信息
          let userInfo = res.userInfo;
          //如果用户信息为空，则弹窗强制用户授权
          if (!userInfo) {
            wx.showModal({
              title: '提示',
              content: '为了获取更好的游戏体验，请先授权获取用户头像和昵称',
              showCancel: false,
            })
          }
          else {
            //返回
            resolve({res:res,type:'rank'});
            //隐藏
            button.hide();
            buttonRank.hide();
            //销毁
            button.destroy();
            buttonRank.destroy();
          }
        })
      })
    }

    openDataContext = new WxgameOpenDataContext();
}

class WxgameOpenDataContext {

    createDisplayObject(type, width, height) {
        const bitmapdata = new egret.BitmapData(sharedCanvas);
        bitmapdata.$deleteSource = false;
        const texture = new egret.Texture();
        texture._setBitmapData(bitmapdata);
        const bitmap = new egret.Bitmap(texture);
        bitmap.width = width;
        bitmap.height = height;

        if (egret.Capabilities.renderMode == "webgl") {
            const renderContext = egret.wxgame.WebGLRenderContext.getInstance();
            const context = renderContext.context;
            ////需要用到最新的微信版本
            ////调用其接口WebGLRenderingContext.wxBindCanvasTexture(number texture, Canvas canvas)
            ////如果没有该接口，会进行如下处理，保证画面渲染正确，但会占用内存。
            if (!context.wxBindCanvasTexture) {
                egret.startTick((timeStarmp) => {
                    egret.WebGLUtils.deleteWebGLTexture(bitmapdata.webGLTexture);
                    bitmapdata.webGLTexture = null;
                    return false;
                }, this);
            }
        }
        return bitmap;
    }


    postMessage(data) {
        const openDataContext = wx.getOpenDataContext();
        openDataContext.postMessage(data);
    }
}


window.platform = new WxgamePlatform();