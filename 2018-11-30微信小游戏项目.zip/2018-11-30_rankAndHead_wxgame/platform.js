/**
 * 请在白鹭引擎的Main.ts中调用 platform.login() 方法调用至此处。
 */
//屏幕宽高
var screenWidth;
var screenHeight;

class WxgamePlatform {

    name = 'wxgame'

    login() {
        return new Promise((resolve, reject) => {
            wx.login({
                success: (res) => {
                    resolve(res)
                }
            })
        })
    }

    getUserInfo() {
        return new Promise((resolve, reject) => {
            wx.getUserInfo({
                withCredentials: true,
                success: function (res) {
                    var userInfo = res.userInfo
                    var nickName = userInfo.nickName
                    var avatarUrl = userInfo.avatarUrl
                    var gender = userInfo.gender //性别 0：未知、1：男、2：女
                    var province = userInfo.province
                    var city = userInfo.city
                    var country = userInfo.country
                    resolve(userInfo);
                }
            })
        })
    }

    //得到机器信息(可补充)
    getSystemInfoSync() {
      const res = wx.getSystemInfoSync();
      screenHeight = res.screenHeight;
      screenWidth = res.screenWidth;
      console.log(`手机屏幕宽高${screenHeight}/${screenWidth}`); 
      //返回值回Egret
      return res;
    }


    //创建全屏授权按钮,只有在真机上才可看到
    //style在文档中有很多事必填的，但其实不需要
    createUserInfoButton() {
      return new Promise((resolve,reject)=>{
        let button = wx.createUserInfoButton({
          type: 'text',
          text: '此为占据全屏的授权按钮，可将此文本size设为0',
          style: {
            left: 0,
            right: 0,
            width: screenWidth,
            height: screenHeight,
            color: '#ffffff',
            fontSize: 16,
          }
        })
        //显示
        button.show();
        //添加监听
        button.onTap((res) => {
          resolve(res);
          //隐藏
          button.hide();
          //销毁
          button.destory();
        })
      })
    }

    openDataContext = new WxgameOpenDataContext();
}

class WxgameOpenDataContext {

    createDisplayObject(type, width, height) {
        const bitmapdata = new egret.BitmapData(sharedCanvas);
        bitmapdata.$deleteSource = false;
        const texture = new egret.Texture();
        texture._setBitmapData(bitmapdata);
        const bitmap = new egret.Bitmap(texture);
        bitmap.width = width;
        bitmap.height = height;

        if (egret.Capabilities.renderMode == "webgl") {
            const renderContext = egret.wxgame.WebGLRenderContext.getInstance();
            const context = renderContext.context;
            ////需要用到最新的微信版本
            ////调用其接口WebGLRenderingContext.wxBindCanvasTexture(number texture, Canvas canvas)
            ////如果没有该接口，会进行如下处理，保证画面渲染正确，但会占用内存。
            if (!context.wxBindCanvasTexture) {
                egret.startTick((timeStarmp) => {
                    egret.WebGLUtils.deleteWebGLTexture(bitmapdata.webGLTexture);
                    bitmapdata.webGLTexture = null;
                    return false;
                }, this);
            }
        }
        return bitmap;
    }


    postMessage(data) {
        const openDataContext = wx.getOpenDataContext();
        openDataContext.postMessage(data);
    }
}


window.platform = new WxgamePlatform();